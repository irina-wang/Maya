var class_ufe_1_1_notification_guard =
[
    [ "NotificationGuard", "class_ufe_1_1_notification_guard.html#af9229e8242082501dbc15044275239d1", null ],
    [ "~NotificationGuard", "class_ufe_1_1_notification_guard.html#a237d0c6fc192bf5bc1e3ef406148f2da", null ],
    [ "NotificationGuard", "class_ufe_1_1_notification_guard.html#ad4492b0476ebba2da97e54845e355b71", null ],
    [ "operator &", "class_ufe_1_1_notification_guard.html#aecbf15dc0398e285d49836d24ff80dda", null ],
    [ "fSubject", "class_ufe_1_1_notification_guard.html#a8f70e9b2382320e1a36fa510f3826306", null ]
];