var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "peptide", "dir_f322a2547b98843d9ce2a96fd9ed3b33.html", "dir_f322a2547b98843d9ce2a96fd9ed3b33" ],
    [ "ufe", "dir_835eff7df150138af52bcde19e0af070.html", "dir_835eff7df150138af52bcde19e0af070" ]
];