var _cfg_warning_macros_8h =
[
    [ "PEPTIDE_DO_PRAGMA", "_cfg_warning_macros_8h.html#a403f7adb080af63b53966b1400422c04", null ],
    [ "PEPTIDE_WARNING_DISABLE", "_cfg_warning_macros_8h.html#a0f315fd5bdb8c734683430d6d5eab090", null ],
    [ "PEPTIDE_WARNING_DISABLE_CLANG", "_cfg_warning_macros_8h.html#a2899d90918652cc22be70ff931b83bc3", null ],
    [ "PEPTIDE_WARNING_DISABLE_CLANG_80", "_cfg_warning_macros_8h.html#afc5bad49bbb67a0989d17903c31ef1b6", null ],
    [ "PEPTIDE_WARNING_DISABLE_GCC", "_cfg_warning_macros_8h.html#a8588fbae3e7f97588f32d005188f5dc8", null ],
    [ "PEPTIDE_WARNING_DISABLE_MSC", "_cfg_warning_macros_8h.html#ac91439ed071ef4e3d2100179243d5b6f", null ],
    [ "PEPTIDE_WARNING_POP", "_cfg_warning_macros_8h.html#a956f207aa958f0615b237b5f3133519c", null ],
    [ "PEPTIDE_WARNING_POP_SYSTEM_HEADER_MSC", "_cfg_warning_macros_8h.html#aea183dab1eee1395512e9efc0aa1bd1b", null ],
    [ "PEPTIDE_WARNING_PUSH", "_cfg_warning_macros_8h.html#aed7cb8a15280eb7d3864ec439fbe23b7", null ],
    [ "PEPTIDE_WARNING_PUSH_SYSTEM_HEADER_MSC", "_cfg_warning_macros_8h.html#a96abfcd146eaa378026930e95378a75a", null ]
];