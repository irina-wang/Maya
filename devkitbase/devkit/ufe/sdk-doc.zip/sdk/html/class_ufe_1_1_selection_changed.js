var class_ufe_1_1_selection_changed =
[
    [ "SelectionChanged", "class_ufe_1_1_selection_changed.html#a082edb42112d3b522c91b9d09d7fc956", null ],
    [ "SelectionChanged", "class_ufe_1_1_selection_changed.html#a7507c015c28456b9df93ff799b3fc074", null ],
    [ "~SelectionChanged", "class_ufe_1_1_selection_changed.html#a553e2cd91a704c7ea01c990ed038f5d0", null ]
];