var class_ufe_1_1_attribute_enum_string =
[
    [ "EnumValues", "class_ufe_1_1_attribute_enum_string.html#ac72b858090d92ba2b4897f0c9f049620", null ],
    [ "Ptr", "class_ufe_1_1_attribute_enum_string.html#a0e9b88bed419db15fd55b1d323c4a964", null ],
    [ "Attribute", "class_ufe_1_1_attribute_enum_string.html#a9401eb6e03cf4b3c8f15df1d672efe3b", null ],
    [ "Attribute", "class_ufe_1_1_attribute_enum_string.html#ab625a50e549e94e40a7f87fd8c2679f4", null ],
    [ "Attribute", "class_ufe_1_1_attribute_enum_string.html#afbe1bd9d159ca93421363f60b7089311", null ],
    [ "get", "class_ufe_1_1_attribute_enum_string.html#a7735ed95ff10274438e6a87bc5a69d6d", null ],
    [ "getEnumValues", "class_ufe_1_1_attribute_enum_string.html#a3df9589b13aeb32add1d41a802fab9b5", null ],
    [ "set", "class_ufe_1_1_attribute_enum_string.html#ada7d1f4f9d9e410f5e24c146d58532dc", null ],
    [ "setCmd", "class_ufe_1_1_attribute_enum_string.html#a28f646834049382f94122ccf757a6208", null ],
    [ "type", "class_ufe_1_1_attribute_enum_string.html#a1c8b71b9e4624f90a582da7a06a4eb14", null ]
];