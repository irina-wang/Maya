var class_ufe_1_1_observer =
[
    [ "Ptr", "class_ufe_1_1_observer.html#a5d10627523508fc3fa9a2611d700861e", null ],
    [ "WeakPtr", "class_ufe_1_1_observer.html#a0d2a72cbcbae34b03bcbc98424cca719", null ],
    [ "~Observer", "class_ufe_1_1_observer.html#a161681295a8841e798a89b5612deb547", null ],
    [ "Observer", "class_ufe_1_1_observer.html#a6f4ac07f8f3410ebf927d28feebd5a39", null ],
    [ "operator()", "class_ufe_1_1_observer.html#a271c27faf18ff8fe4b8e8145acf6dfe5", null ]
];