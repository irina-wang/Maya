var class_ufe_1_1_attribute_value_changed =
[
    [ "AttributeChanged", "class_ufe_1_1_attribute_value_changed.html#a41015e63b1ad658520feef9c60feda7d", null ],
    [ "AttributeChanged", "class_ufe_1_1_attribute_value_changed.html#a11406aa990967072e52da8754edcbfc9", null ]
];