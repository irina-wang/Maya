var class_ufe_1_1_selection_composite_notification =
[
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", "struct_ufe_1_1_selection_composite_notification_1_1_op" ],
    [ "Ops", "class_ufe_1_1_selection_composite_notification.html#ac6f7259751353ea72cf0f02021f2a401", null ],
    [ "OpType", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3", [
      [ "Append", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3a255d7ce3b7e02e2ae24ffcb63f6b3d02", null ],
      [ "Remove", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3a1325f9fc1a79cf8caa9d75c78772ba5d", null ],
      [ "Insert", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3af46d318f1c390633f2b5a3def3d03a28", null ],
      [ "Clear", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3ad8e248380b6b5c1075738557fcd2394d", null ],
      [ "ReplaceWith", "class_ufe_1_1_selection_composite_notification.html#ac85e42658a738057eae201b6ff97dbf3ae3133b27cade6662929e61886df35fa9", null ]
    ] ],
    [ "SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html#ad86e80fd7617d55e75b222e9437c98fd", null ],
    [ "SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html#aced7179cd66a34e4139d269bc86b4a62", null ],
    [ "~SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html#a9f03988b90392add1900f77cd3a62838", null ],
    [ "appendAppendOp", "class_ufe_1_1_selection_composite_notification.html#af460b5e847f86b063f6dd6b3469b4ed9", null ],
    [ "appendClearOp", "class_ufe_1_1_selection_composite_notification.html#a1021b67750e563a9d5f2f59e18b06a9e", null ],
    [ "appendInsertOp", "class_ufe_1_1_selection_composite_notification.html#aac12047e9ec4cba721b97620b1475d6a", null ],
    [ "appendRemoveOp", "class_ufe_1_1_selection_composite_notification.html#a9054f2405c3f8e11b9286c137cba51ad", null ],
    [ "appendReplaceWithOp", "class_ufe_1_1_selection_composite_notification.html#ae0d3d0d65107f5127c6f4f327d2dfa85", null ],
    [ "begin", "class_ufe_1_1_selection_composite_notification.html#aec5ce917603fb7fd22a2d151527f93ae", null ],
    [ "begin", "class_ufe_1_1_selection_composite_notification.html#a6941a8bda153fc27cbc3a8a88c56bc22", null ],
    [ "cbegin", "class_ufe_1_1_selection_composite_notification.html#a741f22a9a6d2fcb028d9d22b84c36c1b", null ],
    [ "cend", "class_ufe_1_1_selection_composite_notification.html#ad6ed67da9659aaa11fc438bc2b6f229b", null ],
    [ "empty", "class_ufe_1_1_selection_composite_notification.html#a3a9f0cef2aeb7803689f54d85f43ea87", null ],
    [ "end", "class_ufe_1_1_selection_composite_notification.html#add72cc13b0d45d90813cfcd21f5274bd", null ],
    [ "end", "class_ufe_1_1_selection_composite_notification.html#a6ba0cf65e62df7b99c2424029114de57", null ],
    [ "size", "class_ufe_1_1_selection_composite_notification.html#aaa0225960dcabffeb2a671176c9c6b52", null ],
    [ "fOps", "class_ufe_1_1_selection_composite_notification.html#acedfddfeda773b160b7f826041a3ef06", null ]
];