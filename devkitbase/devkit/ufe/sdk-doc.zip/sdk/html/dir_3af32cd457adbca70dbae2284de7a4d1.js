var dir_3af32cd457adbca70dbae2284de7a4d1 =
[
    [ "VerFormat.h", "_ver_format_8h.html", [
      [ "VersionFormat", "class_peptide_1_1_version_format.html", "class_peptide_1_1_version_format" ]
    ] ],
    [ "VerInfo.h", "_ver_info_8h.html", [
      [ "VersionInfo", "class_peptide_1_1_version_info.html", "class_peptide_1_1_version_info" ]
    ] ]
];