var _cfg_compiler_macros_8h =
[
    [ "__has_feature", "_cfg_compiler_macros_8h.html#af989845e24678c452b9222afdac95e7f", null ],
    [ "PEPTIDE_AT_MOST_MSVC2015", "_cfg_compiler_macros_8h.html#a664fb1db02b9a73896d15f2444d0e369", null ],
    [ "PEPTIDE_ENABLE_ECBO", "_cfg_compiler_macros_8h.html#ad32b1112b915982b357436e34d91e540", null ],
    [ "PEPTIDE_EXPORT_UNIX", "_cfg_compiler_macros_8h.html#a60d379592393636ce4bcaf3f56aefd5b", null ],
    [ "PEPTIDE_HAS_CXX_RTTI", "_cfg_compiler_macros_8h.html#abe26adf9f866609794aa695f5fb4a62b", null ],
    [ "PEPTIDE_IS_CLANG", "_cfg_compiler_macros_8h.html#a10add1881b943abf0ad2a5a221076174", null ],
    [ "PEPTIDE_IS_GCC", "_cfg_compiler_macros_8h.html#a1590cdad685f26b61257831a7fbd9687", null ],
    [ "PEPTIDE_IS_INTEL", "_cfg_compiler_macros_8h.html#aa85e6351c82f88435a8a5b43b5563f6c", null ],
    [ "PEPTIDE_IS_MSC", "_cfg_compiler_macros_8h.html#a07bed635d30f709423010e9d4e3d8f4e", null ]
];